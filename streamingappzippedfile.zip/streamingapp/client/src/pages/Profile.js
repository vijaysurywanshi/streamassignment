import React, { useState, useEffect } from 'react';
import {
  Container,
  Paper,
  Typography,
  Box,
  Divider,
  List,
  ListItem,
  ListItemText,
  CircularProgress,
  Alert,
  Chip,
} from '@mui/material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';

const Profile = () => {
  const { user } = useAuth();
  const [transactions, setTransactions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    fetchTransactions();
  }, []);

  const fetchTransactions = async () => {
    try {
      const response = await axios.get('/api/wallet/transactions');
      setTransactions(response.data);
    } catch (error) {
      setError('Failed to fetch transactions');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (date) => {
    return new Date(date).toLocaleString();
  };

  const getTransactionColor = (type) => {
    switch (type) {
      case 'SEND':
        return 'error';
      case 'RECEIVE':
        return 'success';
      case 'ADMIN_RESET':
        return 'warning';
      case 'ADMIN_ADD':
        return 'info';
      default:
        return 'default';
    }
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="80vh"
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="md" sx={{ mt: 4, mb: 4 }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Box mb={4}>
          <Typography variant="h4" gutterBottom>
            Profile
          </Typography>
          <Typography variant="body1" gutterBottom>
            Username: {user.username}
          </Typography>
          <Typography variant="body1" gutterBottom>
            Email: {user.email}
          </Typography>
          <Typography variant="h6" color="primary" gutterBottom>
            Wallet Balance: {user.wallet?.balance || 0} coins
          </Typography>
        </Box>

        <Divider sx={{ mb: 4 }} />

        <Typography variant="h5" gutterBottom>
          Transaction History
        </Typography>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        {transactions.length === 0 ? (
          <Typography variant="body1" color="textSecondary" align="center">
            No transactions yet
          </Typography>
        ) : (
          <List>
            {transactions.map((transaction, index) => (
              <React.Fragment key={transaction._id || index}>
                <ListItem alignItems="flex-start">
                  <ListItemText
                    primary={
                      <Box display="flex" alignItems="center" gap={1}>
                        <Chip
                          label={transaction.type}
                          color={getTransactionColor(transaction.type)}
                          size="small"
                        />
                        <Typography variant="subtitle1">
                          {transaction.amount} coins
                        </Typography>
                      </Box>
                    }
                    secondary={
                      <>
                        <Typography component="span" variant="body2" color="text.primary">
                          {transaction.type === 'SEND'
                            ? `Sent to: ${transaction.to?.username || 'Unknown'}`
                            : transaction.type === 'RECEIVE'
                            ? `Received from: ${transaction.from?.username || 'Unknown'}`
                            : 'Admin Transaction'}
                        </Typography>
                        <br />
                        <Typography variant="body2" color="text.secondary">
                          {formatDate(transaction.timestamp)}
                        </Typography>
                      </>
                    }
                  />
                </ListItem>
                {index < transactions.length - 1 && <Divider />}
              </React.Fragment>
            ))}
          </List>
        )}
      </Paper>
    </Container>
  );
};

export default Profile;

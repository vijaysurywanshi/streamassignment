import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  Container,
  Paper,
  Typography,
  Box,
  Button,
  TextField,
  Grid,
  CircularProgress,
  Alert,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Snackbar,
} from '@mui/material';
import { Send as SendIcon } from '@mui/icons-material';
import { useAuth } from '../context/AuthContext';
import axios from 'axios';
import io from 'socket.io-client';

const Stream = () => {
  const { id: streamId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [stream, setStream] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [coinAmount, setCoinAmount] = useState('');
  const [sendingCoins, setSendingCoins] = useState(false);
  const [showCoinDialog, setShowCoinDialog] = useState(false);
  const [notification, setNotification] = useState('');
  const [mediaStream, setMediaStream] = useState(null);
  const socketRef = useRef();
  const videoRef = useRef();
  const peerConnectionRef = useRef();

  useEffect(() => {
    let mounted = true;

    const initializeStream = async () => {
      if (mounted) {
        try {
          await fetchStreamDetails();
          setupSocket();
          if (stream?.streamer._id === user._id) {
            await setupStreamerVideo();
          }
        } catch (err) {
          console.error('Error initializing stream:', err);
          setError('Failed to initialize stream: ' + err.message);
        }
      }
    };

    initializeStream();

    return () => {
      mounted = false;
      cleanupStream();
    };
  }, [user._id]);

  const cleanupStream = () => {
    // Cleanup media stream
    if (mediaStream) {
      mediaStream.getTracks().forEach(track => track.stop());
    }

    // Cleanup peer connection
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close();
    }

    // Cleanup socket
    if (socketRef.current) {
      socketRef.current.disconnect();
    }
  };

  const setupStreamerVideo = async () => {
    console.log('Setting up streamer video...');
    try {
      const constraints = {
        video: {
          width: { ideal: 1280 },
          height: { ideal: 720 },
          frameRate: { ideal: 30 }
        },
        audio: true
      };

      console.log('Requesting media with constraints:', constraints);
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      console.log('Got media stream:', stream);
      
      setMediaStream(stream);
      
      if (videoRef.current) {
        console.log('Setting video source...');
        videoRef.current.srcObject = stream;
        await videoRef.current.play().catch(e => console.error('Error playing video:', e));
      }

      await setupWebRTC(stream);
    } catch (error) {
      console.error('Error accessing media devices:', error);
      setError('Failed to access camera and microphone. Please make sure they are properly connected and permissions are granted.');
    }
  };

  const setupWebRTC = async (stream) => {
    try {
      const configuration = {
        iceServers: [
          { urls: 'stun:stun.l.google.com:19302' },
          { urls: 'stun:stun1.l.google.com:19302' },
        ]
      };

      console.log('Creating peer connection...');
      const peerConnection = new RTCPeerConnection(configuration);
      peerConnectionRef.current = peerConnection;

      // Add tracks to the peer connection
      stream.getTracks().forEach(track => {
        console.log('Adding track to peer connection:', track);
        peerConnection.addTrack(track, stream);
      });

      // Handle ICE candidates
      peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
          console.log('Got ICE candidate:', event.candidate);
          socketRef.current.emit('ice-candidate', {
            candidate: event.candidate,
            streamId
          });
        }
      };

      peerConnection.oniceconnectionstatechange = () => {
        console.log('ICE connection state:', peerConnection.iceConnectionState);
      };

      // Create and send offer if streamer
      if (stream?.streamer._id === user._id) {
        console.log('Creating offer...');
        const offer = await peerConnection.createOffer();
        await peerConnection.setLocalDescription(offer);
        
        socketRef.current.emit('stream-offer', {
          offer: offer,
          streamId
        });
      }
    } catch (error) {
      console.error('WebRTC setup error:', error);
      setError('Failed to setup video streaming: ' + error.message);
    }
  };

  const setupSocket = () => {
    try {
      console.log('Setting up socket connection...');
      socketRef.current = io(process.env.REACT_APP_SOCKET_URL || 'http://localhost:5000');
      
      socketRef.current.on('connect', () => {
        console.log('Connected to socket server');
        socketRef.current.emit('join-stream', streamId);
      });

      socketRef.current.on('connect_error', (error) => {
        console.error('Socket connection error:', error);
        setError('Failed to connect to stream server: ' + error.message);
      });

      socketRef.current.on('stream-offer', async ({ offer }) => {
        console.log('Received stream offer');
        if (!peerConnectionRef.current) {
          await setupWebRTC(new MediaStream());
        }
        await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(offer));
        const answer = await peerConnectionRef.current.createAnswer();
        await peerConnectionRef.current.setLocalDescription(answer);
        
        socketRef.current.emit('stream-answer', {
          answer: answer,
          streamId
        });
      });

      socketRef.current.on('stream-answer', async ({ answer }) => {
        console.log('Received stream answer');
        if (peerConnectionRef.current) {
          await peerConnectionRef.current.setRemoteDescription(new RTCSessionDescription(answer));
        }
      });

      socketRef.current.on('ice-candidate', async ({ candidate }) => {
        console.log('Received ICE candidate');
        if (peerConnectionRef.current) {
          await peerConnectionRef.current.addIceCandidate(new RTCIceCandidate(candidate));
        }
      });

      socketRef.current.on('coins-received', ({ amount }) => {
        setNotification(`Received ${amount} coins!`);
      });

      socketRef.current.on('stream-ended', () => {
        setNotification('Stream has ended');
        setTimeout(() => navigate('/'), 2000);
      });
    } catch (error) {
      console.error('Socket setup error:', error);
      setError('Failed to setup stream connection: ' + error.message);
    }
  };

  const fetchStreamDetails = async () => {
    try {
      const response = await axios.get(`/api/streams/${streamId}`);
      setStream(response.data);
    } catch (error) {
      console.error('Stream fetch error:', error);
      setError('Failed to fetch stream details: ' + error.response?.data?.message || error.message);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const handleSendCoins = async () => {
    if (!coinAmount || isNaN(coinAmount) || coinAmount <= 0) {
      setError('Please enter a valid amount');
      return;
    }

    setSendingCoins(true);
    try {
      await axios.post('/api/wallet/transfer', {
        receiverId: stream.streamer._id,
        amount: Number(coinAmount)
      });

      socketRef.current.emit('send-coins', {
        streamerId: stream.streamer._id,
        amount: Number(coinAmount),
        senderId: user._id
      });

      setShowCoinDialog(false);
      setCoinAmount('');
      setNotification('Coins sent successfully!');
    } catch (error) {
      setError(error.response?.data?.message || 'Failed to send coins');
    } finally {
      setSendingCoins(false);
    }
  };

  const handleEndStream = async () => {
    try {
      await axios.post(`/api/streams/${streamId}/end`);
      socketRef.current.emit('stream-ended', streamId);
      setNotification('Stream ended successfully');
      setTimeout(() => navigate('/'), 2000);
    } catch (error) {
      setError('Failed to end stream');
    }
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="80vh"
      >
        <CircularProgress />
      </Box>
    );
  }

  if (!stream) {
    return (
      <Container maxWidth="md" sx={{ mt: 4 }}>
        <Alert severity="error">Stream not found</Alert>
      </Container>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Paper elevation={3}>
            <Box
              sx={{
                width: '100%',
                height: 0,
                paddingBottom: '56.25%',
                position: 'relative',
                backgroundColor: 'grey.900',
              }}
            >
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted={stream?.streamer._id === user._id}
                style={{
                  position: 'absolute',
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                }}
              />
            </Box>
          </Paper>
        </Grid>

        <Grid item xs={12} md={4}>
          <Paper elevation={3} sx={{ p: 2, height: '100%' }}>
            <Typography variant="h5" gutterBottom>
              {stream.title}
            </Typography>
            <Typography variant="body1" gutterBottom>
              {stream.description}
            </Typography>
            <Typography variant="subtitle1" gutterBottom>
              Streamer: {stream.streamer.username}
            </Typography>
            <Typography variant="subtitle2" gutterBottom>
              Viewers: {stream.viewers.length}
            </Typography>

            {stream.streamer._id === user._id ? (
              <Button
                variant="contained"
                color="error"
                fullWidth
                onClick={handleEndStream}
                sx={{ mt: 2 }}
              >
                End Stream
              </Button>
            ) : (
              <Button
                variant="contained"
                color="primary"
                fullWidth
                startIcon={<SendIcon />}
                onClick={() => setShowCoinDialog(true)}
                sx={{ mt: 2 }}
              >
                Send Coins
              </Button>
            )}
          </Paper>
        </Grid>
      </Grid>

      <Dialog open={showCoinDialog} onClose={() => setShowCoinDialog(false)}>
        <DialogTitle>Send Coins to Streamer</DialogTitle>
        <DialogContent>
          <TextField
            autoFocus
            margin="dense"
            label="Amount"
            type="number"
            fullWidth
            value={coinAmount}
            onChange={(e) => setCoinAmount(e.target.value)}
            disabled={sendingCoins}
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowCoinDialog(false)} disabled={sendingCoins}>
            Cancel
          </Button>
          <Button onClick={handleSendCoins} disabled={sendingCoins}>
            {sendingCoins ? <CircularProgress size={24} /> : 'Send'}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={!!notification}
        autoHideDuration={6000}
        onClose={() => setNotification('')}
        message={notification}
      />
    </Container>
  );
};

export default Stream;

import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Button,
  Box,
  CircularProgress,
  Alert,
} from '@mui/material';
import { LiveTv } from '@mui/icons-material';
import axios from 'axios';
import { useAuth } from '../context/AuthContext';

const Home = () => {
  const [streams, setStreams] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    fetchStreams();
  }, []);

  const fetchStreams = async () => {
    try {
      const response = await axios.get('/api/streams');
      setStreams(response.data);
    } catch (error) {
      setError('Failed to fetch streams');
    } finally {
      setLoading(false);
    }
  };

  const handleStartStream = () => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    navigate('/create-stream');
  };

  const handleJoinStream = (streamId) => {
    if (!isAuthenticated) {
      navigate('/login');
      return;
    }
    navigate(`/stream/${streamId}`);
  };

  if (loading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="80vh"
      >
        <CircularProgress />
      </Box>
    );
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Box display="flex" justifyContent="space-between" mb={4}>
        <Typography variant="h4" component="h1">
          Live Streams
        </Typography>
        {isAuthenticated && (
          <Button
            variant="contained"
            color="primary"
            startIcon={<LiveTv />}
            onClick={handleStartStream}
          >
            Start Streaming
          </Button>
        )}
      </Box>

      {error && (
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
      )}

      <Grid container spacing={4}>
        {streams.length === 0 ? (
          <Grid item xs={12}>
            <Typography variant="h6" color="textSecondary" align="center">
              No active streams at the moment
            </Typography>
          </Grid>
        ) : (
          streams.map((stream) => (
            <Grid item xs={12} sm={6} md={4} key={stream._id}>
              <Card>
                <CardMedia
                  component="div"
                  sx={{
                    height: 140,
                    backgroundColor: 'grey.800',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  <LiveTv sx={{ fontSize: 60, color: 'grey.500' }} />
                </CardMedia>
                <CardContent>
                  <Typography gutterBottom variant="h5" component="div">
                    {stream.title}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    {stream.description}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Streamer: {stream.streamer.username}
                  </Typography>
                  <Typography variant="body2" color="text.secondary" gutterBottom>
                    Viewers: {stream.viewers.length}
                  </Typography>
                  <Button
                    variant="contained"
                    fullWidth
                    onClick={() => handleJoinStream(stream._id)}
                    sx={{ mt: 2 }}
                  >
                    Join Stream
                  </Button>
                </CardContent>
              </Card>
            </Grid>
          ))
        )}
      </Grid>
    </Container>
  );
};

export default Home;

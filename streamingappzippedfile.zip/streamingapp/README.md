# Live Streaming Platform

A real-time streaming platform built with the MERN stack (MongoDB, Express.js, React.js, Node.js) featuring user authentication, live streaming, and a coin-based interaction system.

## Features

- User Authentication (Register/Login)
- Live Video Streaming
- Real-time Chat
- Coin-based Wallet System
- Stream Creation and Management
- Viewer Interaction System

## Tech Stack

### Frontend
- React.js
- Material-UI
- Socket.io Client
- WebRTC
- Axios

### Backend
- Node.js
- Express.js
- MongoDB
- Socket.io
- JWT Authentication

## Prerequisites

Before running this project, make sure you have:
- Node.js (v14 or higher)
- MongoDB
- npm or yarn

## Installation

1. Clone the repository:
```bash
git clone [your-repo-url]
cd streamingapp
```

2. Install dependencies for both client and server:
```bash
# Install server dependencies
cd server
npm install

# Install client dependencies
cd ../client
npm install
```

3. Create .env files:

Server (.env):
```
MONGODB_URI=your_mongodb_uri
JWT_SECRET=your_jwt_secret
PORT=5000
CLIENT_URL=http://localhost:3000
```

4. Start the application:

In the server directory:
```bash
npm start
```

In the client directory:
```bash
npm start
```

The application will be available at `http://localhost:3000`

## Project Structure

```
streamingapp/
├── client/                 # Frontend React application
│   ├── public/
│   └── src/
│       ├── components/    # Reusable components
│       ├── context/      # React context
│       ├── pages/        # Page components
│       └── App.js        # Main application component
├── server/                # Backend Node.js application
│   ├── models/          # MongoDB models
│   ├── routes/          # API routes
│   ├── middleware/      # Custom middleware
│   └── server.js        # Server entry point
└── README.md
```

## API Endpoints

### Authentication
- POST `/api/auth/register` - Register new user
- POST `/api/auth/login` - User login

### Streams
- POST `/api/streams/create` - Create new stream
- GET `/api/streams` - Get all active streams
- GET `/api/streams/:id` - Get stream by ID
- POST `/api/streams/:id/end` - End stream

### Wallet
- GET `/api/wallet/balance` - Get user's wallet balance
- POST `/api/wallet/transfer` - Transfer coins
- GET `/api/wallet/transactions` - Get transaction history

## Contributing

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License.

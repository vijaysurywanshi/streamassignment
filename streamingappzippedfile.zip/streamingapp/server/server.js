require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const http = require('http');
const socketIo = require('socket.io');

// Import routes (to be created)
const authRoutes = require('./routes/auth.routes');
const streamRoutes = require('./routes/stream.routes');
const walletRoutes = require('./routes/wallet.routes');
const adminRoutes = require('./routes/admin.routes');

const app = express();
const server = http.createServer(app);
const io = socketIo(server, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:3000",
    methods: ["GET", "POST"],
    credentials: true
  }
});

// Middleware
app.use(cors({
  origin: process.env.CLIENT_URL,
  credentials: true
}));
app.use(express.json());

// Database connection
mongoose.connect(process.env.MONGODB_URI)
.then(() => console.log('Connected to MongoDB'))
.catch(err => console.error('MongoDB connection error:', err));

// Store active streams and their connections
const activeStreams = new Map();

io.on('connection', (socket) => {
  console.log('Client connected:', socket.id);

  socket.on('join-stream', (streamId) => {
    socket.join(streamId);
    console.log(`Client ${socket.id} joined stream ${streamId}`);
  });

  // Handle stream offer from broadcaster
  socket.on('stream-offer', ({ offer, streamId }) => {
    socket.to(streamId).emit('stream-offer', { offer });
    activeStreams.set(streamId, socket.id);
  });

  // Handle stream answer from viewer
  socket.on('stream-answer', ({ answer, streamId }) => {
    const broadcasterId = activeStreams.get(streamId);
    if (broadcasterId) {
      io.to(broadcasterId).emit('stream-answer', { answer, from: socket.id });
    }
  });

  // Handle ICE candidates
  socket.on('ice-candidate', ({ candidate, streamId }) => {
    socket.to(streamId).emit('ice-candidate', { candidate });
  });

  // Handle coin transfers
  socket.on('send-coins', ({ streamerId, amount, senderId }) => {
    io.to(streamerId).emit('coins-received', { amount, senderId });
  });

  // Handle stream end
  socket.on('stream-ended', (streamId) => {
    io.to(streamId).emit('stream-ended');
    activeStreams.delete(streamId);
  });

  socket.on('disconnect', () => {
    console.log('Client disconnected:', socket.id);
    // Clean up any active streams this socket was broadcasting
    for (const [streamId, broadcasterId] of activeStreams.entries()) {
      if (broadcasterId === socket.id) {
        io.to(streamId).emit('stream-ended');
        activeStreams.delete(streamId);
      }
    }
  });
});

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/streams', streamRoutes);
app.use('/api/admin', adminRoutes);

// Error handling middleware
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!' });
});

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

const express = require('express');
const router = express.Router();
const Stream = require('../models/Stream');
const { auth } = require('../middleware/auth');

// Create a new stream
router.post('/create', auth, async (req, res) => {
  try {
    const { title, description } = req.body;
    
    // Check if user already has an active stream
    const existingStream = await Stream.findOne({
      streamer: req.user._id,
      isActive: true
    });

    if (existingStream) {
      return res.status(400).json({ 
        message: 'You already have an active stream. Please end it before starting a new one.' 
      });
    }

    const stream = new Stream({
      title,
      description,
      streamer: req.user._id,
      isActive: true,
      viewers: [],
    });

    await stream.save();

    // Return stream data without sensitive information
    const streamData = stream.toObject();
    delete streamData.streamKey;
    
    res.status(201).json(streamData);
  } catch (error) {
    console.error('Error creating stream:', error);
    res.status(500).json({ message: 'Failed to create stream' });
  }
});

// Get stream key (only for streamer)
router.get('/:id/key', auth, async (req, res) => {
  try {
    const stream = await Stream.findOne({
      _id: req.params.id,
      streamer: req.user._id,
      isActive: true
    });

    if (!stream) {
      return res.status(404).json({ message: 'Stream not found' });
    }

    res.json({ streamKey: stream.streamKey });
  } catch (error) {
    console.error('Error fetching stream key:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all active streams
router.get('/', async (req, res) => {
  try {
    const streams = await Stream.find({ isActive: true })
      .populate('streamer', 'username')
      .select('-streamKey')
      .sort({ createdAt: -1 });
    res.json(streams);
  } catch (error) {
    console.error('Error fetching streams:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get stream by ID
router.get('/:id', auth, async (req, res) => {
  try {
    const stream = await Stream.findById(req.params.id)
      .populate('streamer', 'username')
      .populate('viewers', 'username')
      .select('-streamKey');
    
    if (!stream) {
      return res.status(404).json({ message: 'Stream not found' });
    }
    
    res.json(stream);
  } catch (error) {
    console.error('Error fetching stream:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// End stream
router.post('/:id/end', auth, async (req, res) => {
  try {
    const stream = await Stream.findOne({
      _id: req.params.id,
      streamer: req.user._id,
      isActive: true
    });
    
    if (!stream) {
      return res.status(404).json({ message: 'Active stream not found' });
    }
    
    stream.isActive = false;
    stream.endedAt = new Date();
    await stream.save();
    
    res.json({ message: 'Stream ended successfully' });
  } catch (error) {
    console.error('Error ending stream:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;

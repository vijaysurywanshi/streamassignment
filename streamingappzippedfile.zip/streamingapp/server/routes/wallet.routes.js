const express = require('express');
const router = express.Router();
const { auth } = require('../middleware/auth');
const User = require('../models/User');
const mongoose = require('mongoose');

// Get wallet balance
router.get('/balance', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id).select('wallet');
    res.json(user.wallet);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Transfer coins
router.post('/transfer', auth, async (req, res) => {
  const session = await mongoose.startSession();
  session.startTransaction();

  try {
    const { receiverId, amount } = req.body;
    const senderId = req.user._id;

    // Prevent self-transfer
    if (senderId.toString() === receiverId.toString()) {
      return res.status(400).json({ message: 'Cannot send coins to yourself' });
    }

    if (amount <= 0) {
      return res.status(400).json({ message: 'Invalid amount' });
    }

    const sender = await User.findById(senderId).session(session);
    const receiver = await User.findById(receiverId).session(session);

    if (!receiver) {
      return res.status(404).json({ message: 'Receiver not found' });
    }

    if (sender.wallet.balance < amount) {
      return res.status(400).json({ message: 'Insufficient balance' });
    }

    // Update sender's wallet
    sender.wallet.balance -= amount;
    sender.wallet.transactions.push({
      type: 'SEND',
      amount,
      to: receiverId,
      timestamp: new Date()
    });

    // Update receiver's wallet
    receiver.wallet.balance += amount;
    receiver.wallet.transactions.push({
      type: 'RECEIVE',
      amount,
      from: senderId,
      timestamp: new Date()
    });

    await sender.save({ session });
    await receiver.save({ session });
    await session.commitTransaction();

    res.json({
      message: 'Transfer successful',
      newBalance: sender.wallet.balance
    });
  } catch (error) {
    await session.abortTransaction();
    console.error('Transfer error:', error);
    res.status(500).json({ message: 'Server error' });
  } finally {
    session.endSession();
  }
});

// Get transaction history
router.get('/transactions', auth, async (req, res) => {
  try {
    const user = await User.findById(req.user._id)
      .select('wallet.transactions')
      .populate('wallet.transactions.from', 'username')
      .populate('wallet.transactions.to', 'username');
    
    res.json(user.wallet.transactions);
  } catch (error) {
    console.error('Transaction history error:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;

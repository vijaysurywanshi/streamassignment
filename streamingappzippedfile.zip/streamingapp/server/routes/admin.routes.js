const express = require('express');
const router = express.Router();
const { adminAuth } = require('../middleware/auth');
const User = require('../models/User');

// Reset user's wallet balance
router.post('/wallet/reset', adminAuth, async (req, res) => {
  try {
    const { userId } = req.body;
    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    const oldBalance = user.wallet.balance;
    user.wallet.balance = 1000; // Reset to default balance
    user.wallet.transactions.push({
      type: 'ADMIN_RESET',
      amount: 1000 - oldBalance,
      from: req.user._id,
      timestamp: new Date()
    });

    await user.save();

    res.json({
      message: 'Wallet balance reset successfully',
      newBalance: user.wallet.balance
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Add coins to user's wallet
router.post('/wallet/add', adminAuth, async (req, res) => {
  try {
    const { userId, amount } = req.body;

    if (amount <= 0) {
      return res.status(400).json({ message: 'Invalid amount' });
    }

    const user = await User.findById(userId);

    if (!user) {
      return res.status(404).json({ message: 'User not found' });
    }

    user.wallet.balance += amount;
    user.wallet.transactions.push({
      type: 'ADMIN_ADD',
      amount,
      from: req.user._id,
      timestamp: new Date()
    });

    await user.save();

    res.json({
      message: 'Coins added successfully',
      newBalance: user.wallet.balance
    });
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

// Get all users' wallet information (for admin dashboard)
router.get('/wallets', adminAuth, async (req, res) => {
  try {
    const users = await User.find()
      .select('username email wallet.balance')
      .sort('-wallet.balance');

    res.json(users);
  } catch (error) {
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;

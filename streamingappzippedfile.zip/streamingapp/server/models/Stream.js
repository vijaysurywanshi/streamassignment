const mongoose = require('mongoose');
const crypto = require('crypto');

const streamSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true,
    trim: true,
  },
  description: {
    type: String,
    trim: true,
  },
  streamer: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true,
  },
  streamKey: {
    type: String,
    required: true,
    unique: true,
    default: () => crypto.randomBytes(20).toString('hex')
  },
  isActive: {
    type: Boolean,
    default: true,
  },
  viewers: [{
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
  }],
  startedAt: {
    type: Date,
    default: Date.now,
  },
  endedAt: {
    type: Date,
  },
  totalCoinsReceived: {
    type: Number,
    default: 0
  }
}, {
  timestamps: true,
});

// Create indexes for better query performance
streamSchema.index({ isActive: 1, createdAt: -1 });
streamSchema.index({ streamer: 1, isActive: 1 });
streamSchema.index({ streamKey: 1 }, { unique: true });

const Stream = mongoose.model('Stream', streamSchema);

module.exports = Stream;
